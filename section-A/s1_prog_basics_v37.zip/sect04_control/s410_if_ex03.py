num_a = 100
num_b = 200

if num_a > num_b:
    print('숫자A가 더 큰수입니다.')
    max = num_a
elif num_a < num_b:
    print('숫자B가 더큰수입니다.')
    max = num_b
else:
    print('숫자A와 숫자B는 같습니다.')

print('숫자A와 숫자B중 최대값은', max, '입니다.')
