
'''
signal_color = input('구구단 몇 단을 출력 할까요? 숫자를 입력하세요:')
nest = [1, 2, 3, 4, 5, 6, 7, 8, 9]
for x in range(10):
    (1*x, 2*x, 3*x, 4*x, 5*x, 6*x, 7*x, 8*x, 9*x,)
'''

# 구구단
str_dan = input('구구단 몇단을 출력할까요? 숫자를 입력하세요:  ')
dan = int(str_dan)

for x in range(9):
    print(dan, ' x ', x+1, ' = ', dan*(x+1))


