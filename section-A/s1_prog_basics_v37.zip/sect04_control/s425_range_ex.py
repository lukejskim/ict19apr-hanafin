# range 함수
result = list(range(10))
print('range(10)     :', result)

result = list(range(5,10))
print('range(5,10)   :', result)

result = list(range(1,10,2))
print('range(1,10,2) :', result)

