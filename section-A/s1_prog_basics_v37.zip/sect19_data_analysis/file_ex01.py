import codecs


def read_csv(filepath, *args, **kwargs):
    # sep = kwargs.get("sep") if kwargs.get("sep") else ","
    sep = kwargs.get("sep", ",")
    # [True 일때의 값] if [condition] else [거짓일때의 값]

    # 1. dict.get
    # 2. [True Value] if condition else [False Value]

    # fp = open(filepath, "r")
    fp = codecs.open(filepath, "r", "utf-8")
    data = fp.read()  # fp.read(), readline(), readlines()
    fp.close()

    elements = []

    rows = data.split("\n")
    columns = rows[0].split(sep)  # ["id", "name", "email"]
    # ["1", "김진수", "bigpycraft@gmail.com"]
    for row in rows[1:]:
        fields = row.split(sep)
        element = {}

        for columnIndex in range(len(columns)):  # index 의 값으로 비교해야 한다.
            column = columns[columnIndex]
            field = fields[columnIndex]
            element[column] = field

        elements.append(element)
    return elements


