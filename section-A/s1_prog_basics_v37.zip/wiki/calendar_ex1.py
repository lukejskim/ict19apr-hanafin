import calendar

print(calendar.calendar(2018, m=6))