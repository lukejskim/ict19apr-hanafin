# 중복 제거 및 정렬
beast = ["lion", "tiger", "wolf", "tiger", "lion", "bear", "lion" ]
print(beast)

unique_beast = list(set(beast))
print(unique_beast)
sorted_beast = sorted(unique_beast)
print(sorted_beast)

