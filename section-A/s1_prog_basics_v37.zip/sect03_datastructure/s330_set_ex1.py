#세트형 생성
lang = {'Java', 'Java', 'Python', 'C++', 'Python'}
print(lang)
print(type(lang))
print('Python'in lang)
print('Javascript'in lang)
