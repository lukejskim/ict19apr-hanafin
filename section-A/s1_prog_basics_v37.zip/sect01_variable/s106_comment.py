# First comment
print("Hello, Python!")  # second comment
# last comment


# <- 샵 기호로 시작하는 줄은 주석입니다.
a = 12    # 12라는 숫자를 a라는 변수에 대입합니다.
# a 값을 출력해보세요!
print(a)
b = '파이선의 주석은 샵기호(#)로 시작합니다.'
print(b)


# 이 줄은 라인 코멘트입니다
print ("Hello World!")

print ("Hello World!")    # 이것도 라인 코멘트입니다
print ("Hello World!")    # 이것도 라인 코멘트입니다

"""
이것은 블럭 코멘트입니다.
그래서 여러 줄의 주석을
이렇게 달 수 있습니다.
큰따옴표 3개를 연속으로 적으면 됩니다.
"""
