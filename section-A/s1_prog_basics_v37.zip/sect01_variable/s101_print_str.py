# 문자 출력
print('Hello, Python !!')
print('반갑습니다. \n파이썬세계로 온것을 환영합니다.')
print("문자는 반드시 인용부호(\' \' 혹은 \" \")로 감싸야 합니다.")

print("He can't speak English.")
print('She said, "I play the violin".')


