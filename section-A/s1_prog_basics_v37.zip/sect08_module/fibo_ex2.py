from s1_prog_basics_v36.sect08_module.fibo import *

fib(300)

result = fib2(500)
print(result)




