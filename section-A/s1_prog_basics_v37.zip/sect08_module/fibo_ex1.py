import s1_prog_basics_v36.sect08_module.fibo

fibo = s1_prog_basics_v36.sect08_module.fibo

fibo.fib(20)

fib = fibo.fib
fib(50)






